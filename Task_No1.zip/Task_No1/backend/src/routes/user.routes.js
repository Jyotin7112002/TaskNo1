const express = require('express');
const router = express.Router();
const { getStores, rateStore, updateRating } = require('../controllers/user.controller');
const auth = require('../middleware/auth');

router.use(auth);
router.get('/stores', getStores);
router.post('/stores/:storeId/rate', rateStore);
router.put('/stores/:storeId/rate', updateRating);

module.exports = router;