const express = require('express');
const router = express.Router();
const { getRatings } = require('../controllers/store.controller');
const auth = require('../middleware/auth');

router.use(auth);
router.get('/ratings', getRatings);

module.exports = router;