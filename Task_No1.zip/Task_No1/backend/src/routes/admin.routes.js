const express = require('express');
const router = express.Router();
const { getDashboard, addUser, addStore, listUsers, listStores } = require('../controllers/admin.controller');
const auth = require('../middleware/auth');

router.use(auth);
router.get('/dashboard', getDashboard);
router.post('/users', addUser);
router.post('/stores', addStore);
router.get('/users', listUsers);
router.get('/stores', listStores);

module.exports = router;