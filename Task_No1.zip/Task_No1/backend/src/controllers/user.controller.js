const { PrismaClient } = require('@prisma/client');
const prisma = new PrismaClient();

exports.getStores = async (req, res) => {
  try {
    const stores = await prisma.store.findMany({ include: { ratings: true } });
    res.json(stores);
  } catch (err) {
    res.status(500).json({ error: 'Failed to fetch stores' });
  }
};

exports.rateStore = async (req, res) => {
  const { storeId } = req.params;
  const { rating } = req.body;
  try {
    const newRating = await prisma.rating.create({
      data: {
        rating: parseInt(rating),
        userId: req.user.userId,
        storeId: parseInt(storeId)
      }
    });
    res.status(201).json(newRating);
  } catch (err) {
    res.status(500).json({ error: 'Failed to rate store' });
  }
};

exports.updateRating = async (req, res) => {
  const { storeId } = req.params;
  const { rating } = req.body;
  try {
    const updatedRating = await prisma.rating.updateMany({
      where: {
        storeId: parseInt(storeId),
        userId: req.user.userId
      },
      data: {
        rating: parseInt(rating)
      }
    });
    res.json(updatedRating);
  } catch (err) {
    res.status(500).json({ error: 'Failed to update rating' });
  }
};