const { PrismaClient } = require('@prisma/client');
const prisma = new PrismaClient();

exports.getDashboard = async (req, res) => {
  try {
    const users = await prisma.user.count();
    const stores = await prisma.store.count();
    const ratings = await prisma.rating.count();
    res.json({ totalUsers: users, totalStores: stores, totalRatings: ratings });
  } catch (err) {
    res.status(500).json({ error: 'Failed to fetch dashboard data' });
  }
};

exports.addUser = async (req, res) => {
  const { name, email, password, address, role } = req.body;
  try {
    const hashedPassword = await bcrypt.hash(password, 10);
    const user = await prisma.user.create({
      data: { name, email, password: hashedPassword, address, role }
    });
    res.status(201).json({ user });
  } catch (err) {
    res.status(500).json({ error: 'Failed to add user' });
  }
};

exports.addStore = async (req, res) => {
  const { name, email, address } = req.body;
  try {
    const store = await prisma.store.create({
      data: { name, email, address }
    });
    res.status(201).json({ store });
  } catch (err) {
    res.status(500).json({ error: 'Failed to add store' });
  }
};

exports.listUsers = async (req, res) => {
  try {
    const users = await prisma.user.findMany();
    res.json(users);
  } catch (err) {
    res.status(500).json({ error: 'Failed to fetch users' });
  }
};

exports.listStores = async (req, res) => {
  try {
    const stores = await prisma.store.findMany({ include: { ratings: true } });
    res.json(stores);
  } catch (err) {
    res.status(500).json({ error: 'Failed to fetch stores' });
  }
};