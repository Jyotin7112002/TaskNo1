const { PrismaClient } = require('@prisma/client');
const prisma = new PrismaClient();

exports.getRatings = async (req, res) => {
  try {
    const ratings = await prisma.rating.findMany({
      where: {
        store: {
          ownerId: req.user.userId
        }
      },
      include: {
        user: true,
        store: true
      }
    });
    res.json(ratings);
  } catch (err) {
    res.status(500).json({ error: 'Failed to fetch ratings' });
  }
};