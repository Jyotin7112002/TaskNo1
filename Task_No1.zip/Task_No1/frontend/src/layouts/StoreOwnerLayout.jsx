import React from 'react';
import Header from '../components/Header';

const StoreOwnerLayout = ({ children }) => {
  return (
    <div>
      <Header />
      <main className="p-4 bg-gray-50 min-h-screen">
        <h2 className="text-2xl font-semibold mb-4">Store Owner Dashboard</h2>
        {children}
      </main>
    </div>
  );
};

export default StoreOwnerLayout;