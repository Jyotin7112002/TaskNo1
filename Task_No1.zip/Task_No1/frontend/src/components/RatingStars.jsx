import React from 'react';

const RatingStars = ({ rating }) => {
  return (
    <div className="flex space-x-1">
      {[1, 2, 3, 4, 5].map((i) => (
        <span key={i}>{i <= rating ? '⭐' : '☆'}</span>
      ))}
    </div>
  );
};

export default RatingStars;