import React from 'react';
import { Link } from 'react-router-dom';

const Header = () => (
  <header className="flex justify-between items-center p-4 bg-blue-600 text-white">
    <h1 className="text-xl font-bold">Store Rating App</h1>
    <nav>
      <Link className="px-2" to="/dashboard">Dashboard</Link>
      <Link className="px-2" to="/admin">Admin</Link>
      <Link className="px-2" to="/store">Store Owner</Link>
      <button onClick={() => localStorage.clear()} className="px-2">Logout</button>
    </nav>
  </header>
);

export default Header;