import React from 'react';
import UserLayout from '../layouts/UserLayout';

const Dashboard = () => {
  return (
    <UserLayout>
      <div className="space-y-4">
        <div className="p-4 bg-white rounded shadow">Browse and rate stores</div>
      </div>
    </UserLayout>
  );
};

export default Dashboard;