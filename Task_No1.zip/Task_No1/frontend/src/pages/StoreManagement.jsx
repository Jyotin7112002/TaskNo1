import React, { useEffect, useState } from 'react';
import AdminLayout from '../layouts/AdminLayout';
import { getStores } from '../services/storeService';

const StoreManagement = () => {
  const [stores, setStores] = useState([]);

  useEffect(() => {
    getStores().then(setStores);
  }, []);

  return (
    <AdminLayout>
      <h3 className="text-lg font-semibold mb-2">Store List</h3>
      <table className="w-full table-auto border">
        <thead>
          <tr className="bg-gray-100">
            <th className="p-2 border">Name</th>
            <th className="p-2 border">Email</th>
            <th className="p-2 border">Address</th>
            <th className="p-2 border">Rating</th>
          </tr>
        </thead>
        <tbody>
          {stores.map((store) => (
            <tr key={store.id} className="odd:bg-white even:bg-gray-50">
              <td className="p-2 border">{store.name}</td>
              <td className="p-2 border">{store.email}</td>
              <td className="p-2 border">{store.address}</td>
              <td className="p-2 border">{store.rating || 'N/A'}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </AdminLayout>
  );
};

export default StoreManagement;