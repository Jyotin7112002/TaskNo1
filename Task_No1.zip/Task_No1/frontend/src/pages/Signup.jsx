import React, { useState } from 'react';
import { signup } from '../services/authService';
import { validateName, validateEmail, validatePassword, validateAddress } from '../utils/validators';

const Signup = () => {
  const [form, setForm] = useState({ name: '', email: '', address: '', password: '' });
  const [error, setError] = useState('');

  const handleChange = (e) => {
    setForm({ ...form, [e.target.name]: e.target.value });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!validateName(form.name)) return setError('Name must be between 20 and 60 characters.');
    if (!validateEmail(form.email)) return setError('Invalid email.');
    if (!validatePassword(form.password)) return setError('Password must be 8-16 chars with uppercase and special char.');
    if (!validateAddress(form.address)) return setError('Address too long.');

    const res = await signup(form);
    if (res.success) alert('Account created! Please login.');
    else setError(res.message || 'Signup failed');
  };

  return (
    <div className="max-w-md mx-auto mt-10">
      <h2 className="text-xl font-semibold mb-4">Signup</h2>
      {error && <p className="text-red-600">{error}</p>}
      <form onSubmit={handleSubmit} className="space-y-4">
        <input name="name" placeholder="Full Name" className="w-full p-2 border" onChange={handleChange} />
        <input name="email" placeholder="Email" className="w-full p-2 border" onChange={handleChange} />
        <input name="address" placeholder="Address" className="w-full p-2 border" onChange={handleChange} />
        <input name="password" type="password" placeholder="Password" className="w-full p-2 border" onChange={handleChange} />
        <button className="w-full p-2 bg-green-600 text-white">Signup</button>
      </form>
    </div>
  );
};

export default Signup;