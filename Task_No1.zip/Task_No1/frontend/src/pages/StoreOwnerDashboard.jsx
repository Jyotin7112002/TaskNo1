import React from 'react';
import StoreOwnerLayout from '../layouts/StoreOwnerLayout';

const StoreOwnerDashboard = () => {
  return (
    <StoreOwnerLayout>
      <div className="space-y-4">
        <div className="p-4 bg-white rounded shadow">Average Rating: 4.3 ⭐</div>
        <div className="p-4 bg-white rounded shadow">Users who rated: 25</div>
      </div>
    </StoreOwnerLayout>
  );
};

export default StoreOwnerDashboard;