import React from 'react';
import AdminLayout from '../layouts/AdminLayout';

const AdminDashboard = () => {
  return (
    <AdminLayout>
      <div className="grid grid-cols-3 gap-4">
        <div className="p-4 bg-white rounded shadow">Total Users: 100</div>
        <div className="p-4 bg-white rounded shadow">Total Stores: 50</div>
        <div className="p-4 bg-white rounded shadow">Total Ratings: 320</div>
      </div>
    </AdminLayout>
  );
};

export default AdminDashboard;