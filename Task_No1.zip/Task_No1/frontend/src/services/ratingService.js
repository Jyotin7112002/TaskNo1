import axios from 'axios';
const API = import.meta.env.VITE_API_URL || 'http://localhost:5000/api';

export const getRatingsByUser = (userId) => axios.get(`${API}/ratings/user/${userId}`);
export const getRatingsByStore = (storeId) => axios.get(`${API}/ratings/store/${storeId}`);
export const createRating = (userId, storeId, rating) =>
  axios.post(`${API}/ratings`, { userId, storeId, rating });
export const updateRating = (ratingId, newRating) =>
  axios.put(`${API}/ratings/${ratingId}`, { rating: newRating });
export const deleteRating = (ratingId) => axios.delete(`${API}/ratings/${ratingId}`);