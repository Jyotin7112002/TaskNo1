import axios from 'axios';
const API = import.meta.env.VITE_API_URL || 'http://localhost:5000/api';

export const getStores = () => axios.get(`${API}/stores`);
export const getStoreById = (id) => axios.get(`${API}/stores/${id}`);
export const createStore = (data) => axios.post(`${API}/stores`, data);
export const updateStore = (id, data) => axios.put(`${API}/stores/${id}`, data);
export const deleteStore = (id) => axios.delete(`${API}/stores/${id}`);
export const rateStore = (storeId, rating) => axios.post(`${API}/stores/${storeId}/rate`, { rating });