import axios from 'axios';
const API = import.meta.env.VITE_API_URL || 'http://localhost:5000/api';

export const login = (email, password) => axios.post(`${API}/auth/login`, { email, password });
export const signup = (data) => axios.post(`${API}/auth/signup`, data);
export const updatePassword = (data) => axios.put(`${API}/auth/update-password`, data);