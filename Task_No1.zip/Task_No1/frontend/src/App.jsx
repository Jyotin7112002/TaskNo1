// src/App.jsx
import React, { useEffect, useState } from "react";
import { BrowserRouter as Router, Routes, Route } from "react-router-dom";
import { AuthContextProvider } from "./context/AuthContext";
import { getStores } from "./services/storeService"; // Example service
import { getUsers } from "./services/userService"; // Example service
import Navbar from "./components/Navbar";
import HomePage from "./pages/HomePage";
import UserManagement from "./pages/UserManagement";
import StoreManagement from "./pages/StoreManagement";
import LoginPage from "./pages/LoginPage";
import SignupPage from "./pages/SignupPage";
import DashboardPage from "./pages/DashboardPage";
import PrivateRoute from "./components/PrivateRoute"; // Private route handler

const App = () => {
  const [stores, setStores] = useState([]);
  const [users, setUsers] = useState([]);

  useEffect(() => {
    // Fetching stores and users
    getStores()
      .then((response) => setStores(response.data))
      .catch((error) => console.error("Failed to fetch stores", error));

    getUsers()
      .then((response) => setUsers(response.data))
      .catch((error) => console.error("Failed to fetch users", error));
  }, []);

  return (
    <AuthContextProvider>
      <Router>
        <Navbar />
        <Routes>
          <Route path="/" element={<HomePage />} />
          <Route path="/login" element={<LoginPage />} />
          <Route path="/signup" element={<SignupPage />} />

          {/* Private routes */}
          <Route
            path="/dashboard"
            element={
              <PrivateRoute>
                <DashboardPage stores={stores} users={users} />
              </PrivateRoute>
            }
          />
          <Route
            path="/user-management"
            element={
              <PrivateRoute>
                <UserManagement users={users} />
              </PrivateRoute>
            }
          />
          <Route
            path="/store-management"
            element={
              <PrivateRoute>
                <StoreManagement stores={stores} />
              </PrivateRoute>
            }
          />
        </Routes>
      </Router>
    </AuthContextProvider>
  );
};

export default App;
