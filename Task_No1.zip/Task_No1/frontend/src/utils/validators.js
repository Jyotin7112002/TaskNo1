export const validateEmail = (email) => {
    return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email);
  };
  
  export const validatePassword = (password) => {
    return /^(?=.*[A-Z])(?=.*[!@#$%^&*])[A-Za-z\d!@#$%^&*]{8,16}$/.test(password);
  };
  
  export const validateName = (name) => {
    return name.length >= 20 && name.length <= 60;
  };
  
  export const validateAddress = (address) => {
    return address.length <= 400;
  };