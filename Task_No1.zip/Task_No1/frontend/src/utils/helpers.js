export const formatDate = (dateString) => {
    const date = new Date(dateString);
    return date.toLocaleDateString("en-US", {
      weekday: "short",
      year: "numeric",
      month: "short",
      day: "numeric",
    });
  };
  
  export const formatCurrency = (amount) => {
    return new Intl.NumberFormat("en-US", {
      style: "currency",
      currency: "USD",
    }).format(amount);
  };

  export const handleError = (error) => {
    console.error("Error: ", error);
    return error.response ? error.response.data.message : "Something went wrong!";
  };
  
  export const handleSuccess = (message) => {
    console.log("Success: ", message);
    return message;
  };

  export const generateId = () => {
    return `id-${Math.random().toString(36).substr(2, 9)}`;
  };

  export const capitalizeFirstLetter = (str) => {
    return str.charAt(0).toUpperCase() + str.slice(1);
  };

  export const isAdmin = (role) => {
    return role === "System Administrator";
  };
  